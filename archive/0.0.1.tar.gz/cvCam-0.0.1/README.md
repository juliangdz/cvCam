# cvCam
Camera Testing tool using Opencv to build package for SoC
